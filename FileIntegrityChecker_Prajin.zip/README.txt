# Task 1 – File Integrity Checker

## How to Run:

1. Open Command Prompt.
2. Navigate to this folder using:
   cd path/to/this/folder
3. Run the script using:
   python file_checker.py

## Description:
This script monitors file changes by computing SHA-256 hashes and comparing them to previously stored values.

## Files Included:
- file_checker.py
- example.txt
- data.csv